﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace ABMProducts.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        // GET api/values
        [HttpGet]
        public ActionResult<IEnumerable<Product>> Get()
        {
            return products;
        }


        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Product> Get(int id)
        {
            for (int i = 0; i<products.Count ; i++)
            {
                if(products[i].Id == id )
                {
                    return products[i];

                }
            } 
            return NotFound();
            
        }

        // POST api/values
        [HttpPost]
        public void Post([FromBody] Product product)
        {
            int maxID = products[(products.Count)-1].Id;
            if (products.Count !=0)
            {
                product.Id = maxID + 1;
            }
            products.Add(product);
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Product product)
        {
            // products.Find(p => p.Id == id);
            for (int i = 0; i<products.Count ; i++)
            {
                if(products[i].Id == id)
                {
                    products[i] = product;
                    break;
                }
            }
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            for (int i = 0; i<products.Count ; i++)
            {
                if(products[i].Id == id)
                {
                    products.Remove(products[i]);
                }
            }
        }

        public static List<Product> products {get; set; } = new List<Product>()
        {
            new Product()
            {
                Id = 1,
                Name = "Phone",
                Description = "Light",
                
            },
            new Product()
            {
                Id = 2,
                Name = "HeadPhone",
                Description = "Sony brand, black",
            },
            new Product()
            {
                Id = 3,
                Name = "Phone case",
                Description = "Spiderman, far from home",
            }
        };
        
        

    }
}
