using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace _2
{
    public class BookAdvance
    {
        public int Age { get; set; }
        public int NumberOfPage { get; set; }
        public string PrintDetails{ get; set; }
    }
}
