using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace _2
{
    public interface IBookService
    {
        List<Book> GetAll();
        Book Get(int ID);
        void Save(Book book);
        void Delete(int ID);


    }
}
