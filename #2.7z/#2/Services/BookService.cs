using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace _2
{
    public class BookService : IBookService
    {
        private List<Book> List;

        public BookService()
        {
            List = new List<Book>();
            var editorial1 = new Editorial() { ID = 1, Name = "Editorial One", Description = "Test Editorial One" };

            var book = new Book()
            {
                ID = 1,
                Name = "Book One",
                Author = "Lio",
                Colaboration = "Messi",
                Editorial = editorial1,
                BookAdvance = new List<BookAdvance>(),

            };

            book.BookAdvance.Add(new BookAdvance() { NumberOfPage = 32, Age = 2018, PrintDetails = "The Print is Yelow", });

            List.Add(book);
            var book2 = new Book()
            {
                ID = 2,
                Name = "Book Two",
                Author = "Pablito",
                Colaboration = "Lezcano",
                Editorial = editorial1,
                BookAdvance = new List<BookAdvance>()

            };
            book2.BookAdvance.Add(new BookAdvance() { NumberOfPage = 45, Age = 2017, PrintDetails = "This Print is White" });
            List.Add(book2);
            
            //var editorial1 = new Editorial() { ID = 1, Name = "Editorial One", Description = "Test Editorial One" };
            //var book = new Book()
            //List = new List<Book>();
            
            var editorial2 = new Editorial() { ID = 2, Name = "Editorial Two", Description = "Test Editorial two" };
            var book3 = (new Book()
            {
                ID = 3,
                Name = "Libro 3",
                Author = "Juan",
                Editorial = editorial2,
                BookAdvance = new List<BookAdvance>()
            });
            book3.BookAdvance.Add(new BookAdvance() { NumberOfPage = 453, Age = 1998, PrintDetails = "This Print is White" });
            List.Add(book3);
        }

        public List<Book> GetAll()
        {
            return List;
        }

        public Book Get(int ID)
        {
            return List.FirstOrDefault(b => b.ID == ID);
        }


        public void Save(Book book)
        {
            this.Delete(book.ID);
            List.Add(book);
        }

        public void Delete(int ID)
        {
            var book = this.Get(ID);

            if (book != null)
            {
                List.Remove(book);
            }
        }

    }

}

