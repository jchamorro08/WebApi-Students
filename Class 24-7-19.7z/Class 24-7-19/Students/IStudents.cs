using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace  ClassAlumnos
{
    public class StudentsAdvance : Students 
    {
        public string GraduationDate{ get; set; }
        public int TeacherGraguation { get; set; }
        public int TypeTechnical { get; set; }
        public School School { get; set; }
        public List<IStudent> IStudent { get; internal set; }
}
}
