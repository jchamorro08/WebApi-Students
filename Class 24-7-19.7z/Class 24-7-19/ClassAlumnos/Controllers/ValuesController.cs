﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using ClassAlumnos;
namespace ClassAlumnos.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        
        private Students students;

        public ValuesController( Students students) 
        {
            this.students = students;
        }

        // GET api/values
        [HttpGet]
        public ActionResult<IList<Students>> Get()
        {
            return students.GetAll(); 
        }

        // GET api/values/5
        [HttpGet("{id}")]
        public ActionResult<Students> Get(int ID)
        {
            return students.Get(ID);
        }

     
        // POST api/values
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/values/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/values/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
