using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace  ClassAlumnos.Controllers
{
    public class Students
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Age { get; set; }
        public int Course { get; set; }
        public string Division { get; set; }
        //public static List<Students> students { get; internal set; }
}
}
