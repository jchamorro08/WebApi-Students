using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ClassAlumnos
{
    public class ServiceStudents : IServiceStudents
    {
        private List<Students> List;

        public IServiceStudents()
        {
            List = new List<Students>();
            var eschool1 = new School() { ID = 1, Name = "Galileo Galilei", Location = "San Martin" };

            var student = new Students()
            {
                ID = 1,
                Name = "Rodrigo",
                BookAdvance = new List<BookAdvance>(),

            };

            //book.BookAdvance.Add(new BookAdvance() { NumberOfPage = 32, Age = 2018, PrintDetails = "The Print is Yelow", });
            var school2 = new School() { ID = 1, Name = "Comercial", Location = "Ballester" };
            List.Add(student);
            var student2 = new Students()
            {
                ID = 2,
                Name = "Romina",
                BookAdvance = new List<BookAdvance>()

            };
            //book2.BookAdvance.Add(new BookAdvance() { NumberOfPage = 45, Age = 2017, PrintDetails = "This Print is White" });
            List.Add(student2);
            List = new List<Students>();
            
            var school3 = new School() { ID = 2, Name = "Alfonsina Storni", Location = "San Martin" };
            var student3 = new Students()
            {
                ID = 3,
                Name = "Martin",
                BookAdvance = new List<BookAdvance>()
            };
            book3.BookAdvance.Add(new BookAdvance() { NumberOfPage = 453, Age = 1998, PrintDetails = "This Print is White" });
            List.Add(student3);
        }

        public List<Students> GetAll()
        {
            return List;
        }

        public Students Get(int ID)
        {
            return List.FirstOrDefault(b => b.ID == ID);
        }


        public void Save(Students student)
        {
            this.Delete(Students.ID);
            List.Add(Students);
        }

        public void Delete(int ID)
        {
            var student = this.Get(ID);

            if (student != null)
            {
                List.Remove(student);
            }
        }

    }

}

