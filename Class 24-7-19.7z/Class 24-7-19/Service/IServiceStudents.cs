using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace ClassAlumnos
{
    public interface IServiceStudents
    {
        List<Students> GetAll();
        Students Get(int ID);
        void Save(Students students);
        void Delete(int ID);


    }
}
