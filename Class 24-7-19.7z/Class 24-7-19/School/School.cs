using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;

namespace Class_24_7_19
{
    public class School
    {
        public string Name { get; set; }
        public string Location { get; set; }
        public string Description { get; set; }

    }
}
